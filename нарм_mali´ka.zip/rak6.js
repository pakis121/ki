// process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";  // Удаляем эту строку

const mineflayer = require("mineflayer");
const readline = require("readline");
const FlayerCaptcha = require("flayercaptcha");
const autoClickerPlugin = require("mineflayer-autoclicker");
const { createCanvas, loadImage } = require("canvas");
const { exec } = require("child_process"); // Для перезапуска процесса
// Удалён дублирующийся импорт: const bot = require('your-bot-library');
const axios = require("axios");
const path = require("path");
const fs = require("fs");
const { Client, GatewayIntentBits } = require("discord.js");
const { ProxyAgent } = require("proxy-agent");
const socks = require("socks").SocksClient;
const {
  mcUsername,
  mcPassword,
  mcServerHost,
  mcServerPort,
  proxyHost,
  proxyPassword,
  proxyPort,
  proxyUsername,
  web1,
  token,
  channelId,
  messages,
  captchaEnabled: initialCaptchaState = true, // Загружаем состояние капчи из конфига
} = require("./config_rak6.json");
const { createBot } = mineflayer;

// Отключаем предупреждение о устаревшем модуле punycode
process.noDeprecation = true;

// Патчим создание бота для безопасной обработки mount пакетов
const originalCreateBot = mineflayer.createBot;
mineflayer.createBot = function(options) {
    const bot = originalCreateBot(options);
    
    // Переопределяем обработку mount пакетов до их обработки плагином entities
    bot._client.on('mount', function(packet) {
        try {
            // Проверяем наличие необходимых данных
            if (!packet || typeof packet.entityId === 'undefined' || typeof packet.vehicleId === 'undefined') {
                console.log('⚠️ Некорректный mount пакет');
                return;
            }

            // Создаем объект entities если его нет
            if (!bot.entities) {
                bot.entities = {};
            }

            // Создаем или получаем vehicle
            if (!bot.entities[packet.vehicleId]) {
                bot.entities[packet.vehicleId] = {
                    id: packet.vehicleId,
                    type: 'vehicle',
                    position: { x: 0, y: 0, z: 0 },
                    passengers: [],
                    metadata: {},
                    name: 'unknown'
                };
            }

            // Убеждаемся что у vehicle есть массив passengers
            if (!bot.entities[packet.vehicleId].passengers) {
                bot.entities[packet.vehicleId].passengers = [];
            }

            // Создаем или получаем passenger
            if (!bot.entities[packet.entityId]) {
                bot.entities[packet.entityId] = {
                    id: packet.entityId,
                    position: { x: 0, y: 0, z: 0 },
                    metadata: {},
                    name: 'unknown'
                };
            }

            // Безопасно добавляем пассажира
            const vehicle = bot.entities[packet.vehicleId];
            const passenger = bot.entities[packet.entityId];

            if (!vehicle.passengers.includes(passenger)) {
                vehicle.passengers.push(passenger);
            }

            console.log(`✅ Mount пакет обработан: ${packet.entityId} -> ${packet.vehicleId}`);
        } catch (error) {
            console.error('❌ Ошибка при обработке mount пакета:', error);
        }
    });

    return bot;
};

// Создаём майнкрафт-бота с помощью mineflayer
let bot = mineflayer.createBot({
  username: mcUsername,
  password: mcPassword,
  host: mcServerHost,
  port: mcServerPort,
  version: "1.16.5",
  agent: new ProxyAgent({
    protocol: "socks5:",
    host: proxyHost,
    port: proxyPort,
    username: proxyUsername,
    password: proxyPassword,
  }),
  connect: (client) => {
    socks.createConnection(
      {
        proxy: {
          host: proxyHost,
          port: proxyPort,
          type: 5,
          userId: proxyUsername,
          password: proxyPassword,
        },
        command: "connect",
        destination: {
          host: mcServerHost,
          port: mcServerPort,
        },
      },
      (err, info) => {
        if (err) {
          console.log(err);
          return;
        }
        client.setSocket(info.socket);
        client.emit("connect");
      },
    );
  },
});

// Патчим обработчик mount пакетов сразу после создания бота
const originalEmit = bot._client.emit;
bot._client.emit = function(name, data) {
    if (name === 'mount') {
        try {
            console.log(`📦 Получен mount пакет: entityId=${data?.entityId}, vehicleId=${data?.vehicleId}`);
            
            // Проверяем наличие данных
            if (!data) {
                console.log('⚠️ Получен пустой mount пакет');
                return false;
            }

            // Проверяем наличие необходимых ID
            if (typeof data.entityId === 'undefined' || typeof data.vehicleId === 'undefined') {
                console.log('⚠️ Mount пакет не содержит необходимых ID');
                return false;
            }

            // Принудительно создаем объект entities если его нет
            if (!bot.entities) {
                console.log('🔧 Создание объекта entities');
                bot.entities = {};
            }

            // Всегда создаем новый vehicle объект
            console.log(`🚗 Создание/обновление vehicle с ID ${data.vehicleId}`);
            bot.entities[data.vehicleId] = {
                id: data.vehicleId,
                type: 'vehicle',
                position: bot.entities[data.vehicleId]?.position || { x: 0, y: 0, z: 0 },
                passengers: bot.entities[data.vehicleId]?.passengers || [],
                metadata: bot.entities[data.vehicleId]?.metadata || {},
                name: bot.entities[data.vehicleId]?.name || 'unknown'
            };

            // Всегда создаем новый passenger объект
            console.log(`👤 Создание/обновление passenger с ID ${data.entityId}`);
            bot.entities[data.entityId] = {
                id: data.entityId,
                position: bot.entities[data.entityId]?.position || { x: 0, y: 0, z: 0 },
                metadata: bot.entities[data.entityId]?.metadata || {},
                name: bot.entities[data.entityId]?.name || 'unknown'
            };

            // Проверяем что все создалось корректно
            const vehicle = bot.entities[data.vehicleId];
            const passenger = bot.entities[data.entityId];

            if (!vehicle || !vehicle.passengers) {
                console.log('⚠️ Что-то пошло не так при создании vehicle');
                return false;
            }

            if (!passenger) {
                console.log('⚠️ Что-то пошло не так при создании passenger');
                return false;
            }

            console.log('✅ Сущности успешно созданы/обновлены');
            return originalEmit.apply(this, arguments);
        } catch (error) {
            console.error('❌ Ошибка при обработке mount пакета:', error);
            return false;
        }
    }
    return originalEmit.apply(this, arguments);
};

bot.once("spawn", () => console.log("spawned"));

let autoclickerActive = false;
let isSneaking = true;
let autoEat = true;
let showChat = false;
let loops = {}; // Храним активные циклы сообщений
let autoReconnectEnabled = true; // Переменная для отслеживания состояния автопереподключения

const whitelist = [
  "fas13jdja",
    "pakistan_3332",
    "Darkness_Twink3",
    "taqwx321333",
    "The_Darkness_YT",
    "0wl"
];
const hostileMobs = ["zombie", "skeleton", "creeper", "spider", "enderman"];

// Патчим автокликер для безопасной работы с сущностями
const safeAutoClicker = {
    ...autoClickerPlugin,
    inject: function(bot) {
        bot.autoclicker = {
            isClicking: false,
            _swingInterval: null,
            
            start: function() {
                if (this.isClicking) return;
                this.isClicking = true;
                
                this._swingInterval = setInterval(() => {
                    try {
                        if (!bot.entity || !bot.entity.position) return;
                        
                        const entities = Object.values(bot.entities || {}).filter(entity => {
                            try {
                                return entity && 
                                       entity.position && 
                                       entity.type !== 'object' && 
                                       entity.username !== bot.username && 
                                       entity.position.distanceTo(bot.entity.position) <= 4 && 
                                       !['item', 'falling_block'].includes(entity.name);
                            } catch (error) {
                                return false;
                            }
                        });
                        
                        if (entities.length > 0) {
                            bot.swingArm('right');
                            bot.attack(entities[0]);
                        }
                    } catch (error) {
                        console.error('❌ Ошибка в автокликере:', error);
                    }
                }, 750);
                
                console.log('🔫 Автокликер запущен');
            },
            
            stop: function() {
                if (!this.isClicking) return;
                if (this._swingInterval) {
                    clearInterval(this._swingInterval);
                    this._swingInterval = null;
                }
                this.isClicking = false;
                console.log('🛑 Автокликер остановлен');
            }
        };
    }
};

// Загружаем безопасную версию автокликера
bot.loadPlugin(safeAutoClicker.inject);

// Создаём интерфейс для консольных команд
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

let captchaEnabled = initialCaptchaState; // Инициализируем состояние капчи из конфига

// === Команды из консоли ===
rl.on("line", async (input) => {
  const args = input.split(" ");
  const command = args[0];

  switch (command) {
    case "toggleAutoclicker":
      if (autoclickerActive) {
        bot.autoclicker.stop();
        autoclickerActive = false;
      } else {
        bot.autoclicker.start();
        autoclickerActive = true;
      }
      break;
    case "inv":
      // Отправка текстового списка инвентаря в консоль
      showInventoryConsole();
      break;
    case "inventory":
      // Создание скриншота инвентаря и отправка в Discord
      await saveInventorySnapshot().catch((err) => console.error(err));
      break;
    case "sit":
      toggleSneak();
      break;
    case "eat":
      autoEat = !autoEat;

      break;
    case "chat":
      showChat = !showChat;
      console.log(`Отображение чата: ${showChat ? "ВКЛЮЧЕНО" : "ВЫКЛЮЧЕНО"}`);
      break;
    case "autoleave":
      autoLeave = !autoLeave;
      const currentZone = getCurrentZoneName();
      const autoLeaveStatus = autoLeave ? "включен" : "выключен";
      console.log(`🔒 Авто-лив ${autoLeaveStatus}. Текущая зона: ${currentZone}`);
      // Отправляем уведомление в Discord
      const channel = discordBot.channels.cache.get(channelId);
      if (channel) {
        channel.send(`🔒 Авто-лив ${autoLeaveStatus}. Текущая зона: ${currentZone}`);
      }
      break;
    case "slot":
      const slotNumber = parseInt(args[1]);
      if (isNaN(slotNumber) || slotNumber < 0 || slotNumber > 8) {
        const errorMessage =
          "❌ Вы устанавливаете неверный слот. Слот должен быть от 0 до 8.";
        console.log(errorMessage);

        // Отправка сообщения в Discord
        const channel = discordBot.channels.cache.get(channelId);
        if (channel) {
          channel.send(errorMessage);
        }
      } else {
        bot.setQuickBarSlot(slotNumber);
        console.log(`Слот быстрого доступа изменен на: ${slotNumber}`);
      }
      break;
    case "say":
      bot.chat(args.slice(1).join(" "));
      break;
    case "loop":
      if (args.length < 3) {
        console.log("Использование: loop [id] [текст] [мс]");
        return;
      }
      {
        const loopId = args[1];
        const message = args.slice(2, -1).join(" ");
        const delay = parseInt(args[args.length - 1]);
        if (loops[loopId]) {
          console.log(`Цикл '${loopId}' уже запущен.`);
          return;
        }
        startLoop(loopId, message, delay);
      }
      break;
    case "stoploop":
      if (args[1]) {
        stopLoop(args[1]);
      } else {
        stopAllLoops();
      }
      break;
    case "listloop":
      console.log("Активные циклы:", Object.keys(loops));
      break;
    case "players":
      console.log(
        `Игроков в зоне прогрузки: ${Object.keys(bot.players).length}`,
      );
      break;
    case "help":
      showCommands();
      break;
    case "drop":
      if (args[1]) {
        const slot = parseInt(args[1]);
        if (!isNaN(slot)) {
          dropItem(slot);
        } else {
          console.log("❌ Укажите корректный номер слота.");
        }
      }
      break;
    case "startM":
      startMessageLoops();
      break;
    case "stopM":
      stopAllMessageLoops();
      break;
    case "listLoops":
      console.log("Активные циклы сообщений:", Object.keys(messageLoops));
      break;
    case "exit":
      await cleanExit();
      break;
    case "restartBot":
      stopAndRestartBot(); // Команда для перезапуска бота
      break;
    case "recon":
      autoReconnectEnabled = !autoReconnectEnabled;
      const status = autoReconnectEnabled ? 'включено' : 'выключено';
      console.log(`Автоматическое переподключение ${status}`);
      message.reply(`🔄 Автоматическое переподключение ${status}`);
      break;
    case "captcha":
      const captchaStatus = await toggleCaptcha();
      console.log(`Обработка капчи ${captchaStatus}`);
      break;
    case "addzone":
      if (args.length < 6) {
        console.log("Использование: addzone <x> <y> <z> <радиус> <имя>");
        return;
      }
      const result = addTempSafeZone(args[1], args[2], args[3], args[4], args.slice(5).join(" "));
      console.log(result);
      break;
    case "removezone":
      if (args.length < 2) {
        console.log("Использование: removezone <имя>");
        return;
      }
      const removeResult = removeTempSafeZone(args.slice(1).join(" "));
      console.log(removeResult);
      break;
    case "listzones":
      console.log("\nПостоянные зоны:");
      SAFE_ZONES.forEach(zone => {
        console.log(`- ${zone.name}: x=${zone.x}, y=${zone.y}, z=${zone.z}, радиус=${zone.radius}`);
      });
      console.log("\nВременные зоны:");
      if (TEMP_SAFE_ZONES.length === 0) {
        console.log("Нет временных зон");
      } else {
        TEMP_SAFE_ZONES.forEach(zone => {
          console.log(`- ${zone.name}: x=${zone.x}, y=${zone.y}, z=${zone.z}, радиус=${zone.radius}`);
        });
      }
      break;
    default:
      console.log("Неизвестная команда. Введите help для списка.");
  }
});

// === Discord бот ===
const discordBot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

let mcChatEnabled = false; // Пересылка сообщений Minecraft в Discord

// Функция для отправки текстового списка инвентаря в Discord
function showInventoryDiscord(msg) {
  if (!bot.inventory) {
    msg.reply("⚠️ Инвентарь недоступен!");
    return;
  }
  const items = bot.inventory.items();
  if (items.length === 0) {
    msg.reply("🎒 Инвентарь пуст!");
    return;
  }
  let invList = "📦 **Инвентарь:**\n";
  items.forEach((item) => {
    invList += `🔹 ${item.name} (x${item.count})\n`;
  });
  msg.reply(invList);
}

// Обработчик сообщений Discord
discordBot.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  const args = message.content.trim().split(/\s+/);
  const command = args[0].toLowerCase();
  switch (command) {
    case "!say":
      bot.chat(args.slice(1).join(" "));
      message.reply("✅ Сообщение отправлено в чат Minecraft!");
      break;
    case "!on":
      bot.autoclicker.start();
      message.reply("🔫 Автокликер ВКЛЮЧЕН");
      break;
    case "!mcchat":
      mcChatEnabled = !mcChatEnabled;
      message.reply(
        `📢 Пересылка сообщений Minecraft: ${mcChatEnabled ? "ВКЛЮЧЕНА" : "ВЫКЛЮЧЕНА"}`,
      );
      break;
      case "!p":
      const players = Object.values(bot.players)
        .filter(player => player.entity && bot.entity.position.distanceTo(player.entity.position) <= 200)
        .map(player => player.username);

      if (players.length > 0) {
        message.reply(`🎮 Игроки в радиусе 200 блоков: ${players.join(", ")}`);
      } else {
        message.reply("🚫 В радиусе 200 блоков нет игроков.");
      }
      break;
    case "!off":
      bot.autoclicker.stop();
      message.reply("❌ Автокликер ВЫКЛЮЧЕН");
      break;
    case "!inv":
      showInventoryDiscord(message);
      break;
    case "!players":
      message.reply(`🧑‍🤝‍🧑 Игроков рядом: ${Object.keys(bot.players).length}`);
      break;
    case "!exit":
      await message.reply("🚪 Начинаю процесс отключения...");
      await cleanExit();
      break;
    case "!loop":
      if (args.length < 4) {
        message.channel.send("Использование: !loop [id] [текст] [мс]");
        return;
      }
      const loopId = args[1];
      const messageText = args.slice(2, -1).join(" ");
      const delay = parseInt(args[args.length - 1]);
      if (loops[loopId]) {
        message.channel.send(`Цикл '${loopId}' уже запущен.`);
        return;
      }
      startLoop(loopId, messageText, delay);
      message.channel.send(`Цикл '${loopId}' запущен!`);
      break;
    case "!stoploop":
      if (args[1]) {
        stopLoop(args[1]);
        message.channel.send(`Цикл '${args[1]}' остановлен.`);
      } else {
        stopAllLoops();
        message.channel.send("Все циклы остановлены.");
      }
      break;
    case "!listloop":
      if (Object.keys(loops).length === 0) {
        message.channel.send("Нет активных циклов.");
      } else {
        message.channel.send(
          `Активные циклы: ${Object.keys(loops).join(", ")}`,
        );
      }
      break;
    case "!startM":
      startMessageLoops();
      message.reply("Циклы сообщений запущены.");
      break;
    case "!stopM":
      stopAllMessageLoops();
      message.reply("Циклы сообщений остановлены.");
      break;
    case "!listLoops":
      message.reply(
        "Активные циклы сообщений: " + Object.keys(messageLoops).join(", "),
      );
      break;
    case "!eat":
      autoEat = !autoEat;
      message.channel.send(`Авто-еда: ${autoEat ? "ВКЛЮЧЕНА" : "ВЫКЛЮЧЕНА"}`);
      break;
    case "!chat":
      showChat = !showChat;
      message.channel.send(
        `Отображение чата: ${showChat ? "ВКЛЮЧЕНО" : "ВЫКЛЮЧЕНО"}`,
      );
      break;
    case "!slot":
      const slotNumber = parseInt(args[1]);
      if (isNaN(slotNumber) || slotNumber < 0 || slotNumber > 8) {
        const errorMessage =
          "❌ Вы устанавливаете неверный слот. Слот должен быть от 0 до 8.";
        console.log(errorMessage);

        // Отправка сообщения в Discord
        const channel = discordBot.channels.cache.get(channelId);
        if (channel) {
          channel.send(errorMessage);
        }
      } else {
        bot.setQuickBarSlot(slotNumber);
        console.log(`Слот быстрого доступа изменен на: ${slotNumber}`);
      }
      break;
    case "!sit":
      console.log("Команда 'sit' получена.");
      toggleSneak();
      message.reply("👀 Присесть/ползти: Включено/Выключено");
      break;
    case "!invss":
      await saveInventorySnapshot().catch((err) => console.error(err));
      message.reply("📸 Создаётся скриншот инвентаря...");
      break;
    case "!recon":
      autoReconnectEnabled = !autoReconnectEnabled;
      const status = autoReconnectEnabled ? 'включено' : 'выключено';
      message.reply(`🔄 Автоматическое переподключение ${status}`);
      console.log(`Автоматическое переподключение ${status}`);
      break;
    case "!autoleave":
      autoLeave = !autoLeave;
      const currentZone = getCurrentZoneName();
      const autoLeaveDiscordStatus = autoLeave ? "включен" : "выключен";
      message.reply(`🔒 Авто-лив ${autoLeaveDiscordStatus}. Текущая зона: ${currentZone}`);
      console.log(`Авто-лив ${autoLeaveDiscordStatus}. Текущая зона: ${currentZone}`);
      break;
    case "!zones":
      const zonesList = SAFE_ZONES.map(zone => 
        `${zone.name}: x=${zone.x}, y=${zone.y}, z=${zone.z}, радиус=${zone.radius}`
      ).join('\n');
      message.reply(`📍 Безопасные зоны:\n${zonesList}`);
      break;
    case "!captcha":
      const captchaDiscordStatus = await toggleCaptcha();
      message.reply(`🔄 Обработка капчи ${captchaDiscordStatus}`);
      break;
    case "!addzone":
      if (args.length < 6) {
        message.reply("Использование: !addzone <x> <y> <z> <радиус> <имя>");
        return;
      }
      const result = addTempSafeZone(args[1], args[2], args[3], args[4], args.slice(5).join(" "));
      message.reply(result);
      break;
    case "!removezone":
      if (args.length < 2) {
        message.reply("Использование: !removezone <имя>");
        return;
      }
      const removeResult = removeTempSafeZone(args.slice(1).join(" "));
      message.reply(removeResult);
      break;
    case "!listzones":
      let tempZonesList = "**Постоянные зоны:**\n";
      SAFE_ZONES.forEach(zone => {
        tempZonesList += `- ${zone.name}: x=${zone.x}, y=${zone.y}, z=${zone.z}, радиус=${zone.radius}\n`;
      });
      tempZonesList += "\n**Временные зоны:**\n";
      if (TEMP_SAFE_ZONES.length === 0) {
        tempZonesList += "Нет временных зон";
      } else {
        TEMP_SAFE_ZONES.forEach(zone => {
          tempZonesList += `- ${zone.name}: x=${zone.x}, y=${zone.y}, z=${zone.z}, радиус=${zone.radius}\n`;
        });
      }
      message.reply(tempZonesList);
      break;
    default:
      message.reply(
        "❓ Неизвестная команда! Доступные: !say, !on, !off, !inv, !invss, !players, !exit, !loop, !stoploop, !listloops, !eat, !chat, !slot, sit, !mcchat, !p, !recon, !autoleave, !zones, !captcha, !addzone, !removezone, !listzones",
      );
  }
});

// === Функции циклов сообщений ===
function startLoop(loopId, messageText, delay) {
  loops[loopId] = setInterval(() => bot.chat(messageText), delay);
  console.log(`Цикл '${loopId}' запущен с интервалом ${delay} мс.`);
}

function stopLoop(loopId) {
  if (loops[loopId]) {
    clearInterval(loops[loopId]);
    delete loops[loopId];
    console.log(`Цикл '${loopId}' остановлен.`);
  }
}

function stopAllLoops() {
  Object.keys(loops).forEach((loopId) => {
    clearInterval(loops[loopId]);
    delete loops[loopId];
  });
  console.log("Все циклы остановлены.");
}

function showCommands() {
  console.log(`\nДоступные команды:
  - on: Включить автокликер
  - off: Выключить автокликер
  - sit: Переключить приседание
  - eat: Включить/выключить авто-еду
  - chat: Включить/выключить чат
  - autoleave: Включить/выключить авто-выход
  - slot [0-8]: Сменить слот
  - say [текст]: Написать в чат
  - loop [id] [текст] [мс]: Повторять сообщение
  - stoploop [id]: Остановить конкретный цикл
  - stoploop: Остановить все циклы
  - listloops: Показать активные циклы
  - players: Показать игроков рядом
  - inv / inventory: Показать инвентарь (консоль) или создать скриншот и отправить в Discord (!invss)
  - drop [номер слота]: Выбросить предмет из указанного слота
  - help: Показать этот список
  - exit: Выход из программы
  - recon: Включить/выключить автоматическое переподключение
  - autoleave: Включить/выключить авто-выход
  - zones: Показать список безопасных зон
  - captcha: Включить/выключить обработку капчи
  - addzone <x> <y> <z> <радиус> <имя>: Добавить временную безопасную зону
  - removezone <имя>: Удалить временную безопасную зону
  - listzones: Показать список всех зон
  `);
}

// === Функция показа инвентаря в консоли ===
function showInventoryConsole() {
  if (!bot.inventory) {
    console.log("⚠️ Инвентарь недоступен!");
    return;
  }
  const items = bot.inventory.items();
  if (items.length === 0) {
    console.log("📦 Инвентарь пуст!");
    return;
  }
  console.log("\n📦 Содержимое инвентаря:");
  items.forEach((item) => {
    console.log(`🔢 Слот: ${item.slot} | ${item.name} (x${item.count})`);
  });
  console.log("");
}

// === Функция переключения приседания ===
function toggleSneak() {
  isSneaking = !isSneaking;
  bot.setControlState("sneak", isSneaking);
}

bot.on("respawn", async () => {
  try {
    // Сохраняем состояние автокликера, автоеды и автолива
    const wasAutoclickerActive = autoclickerActive;
    const wasAutoEatActive = autoEat;
    const wasAutoLeaveActive = autoLeave; // Сохраняем состояние autoLeave

    // Отключаем автокликер и автоеду
    if (autoclickerActive) {
      bot.autoclicker.stop();
      autoclickerActive = false;
    }

    if (autoEat) {
      autoEat = false;
    }

    // Ждем 1 секунду перед повторным включением
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // Включаем функции снова только если они были активны
    if (wasAutoclickerActive) {
      bot.autoclicker.start();
      autoclickerActive = true;
    }

    if (wasAutoEatActive) {
      autoEat = true;
    }

    // Восстанавливаем состояние autoLeave
    autoLeave = wasAutoLeaveActive;
    
    // Обработка приседания при респавне
    toggleSneak();
    setTimeout(() => {
      toggleSneak();
    }, 1500);

  } catch (error) {
    console.error("Ошибка в обработчике respawn:", error);
  }
});

// === Авто-еда ===
let isEating = false;

async function tryEat() {
  if (!bot.inventory || isEating) return;
  isEating = true;
  
  try {
    const items = bot.inventory.items();
    const foodNames = [
      "apple",
      "bread",
      "cooked_beef",
      "cooked_porkchop",
      "cooked_rabbit",
      "carrot",
      "potato",
      "golden_apple",
      "mushroom_stew",
      "beetroot_soup",
      "cooked_chicken",
      "cooked_mutton",
      "cooked_cod",
      "cooked_salmon",
      "sweet_berries",
      "enchanted_golden_apple",
      "golden_carrot",
    ];
    
    const food = items.find((item) => foodNames.includes(item.name));
    if (!food) {
      isEating = false;
      return;
    }
    
    const previousSlot = bot.quickBarSlot;
    await bot.equip(food, "hand");
    await bot.consume();
    
    setTimeout(() => {
      bot.setQuickBarSlot(previousSlot);
      isEating = false;
    }, 2500);
  } catch (err) {
    console.log("❌ Ошибка при еде:", err);
    isEating = false;
  }
}

bot.on("health", async () => {
  if (bot.food < 20 && autoEat && !isEating) {
    await tryEat();
  }
});

// === Обработчик сообщений в чат (Minecraft) ===
bot.on("message", (message) => {
  if (showChat) console.log(`[CHAT] ${message.toAnsi()}`);
  
  // Пересылка в Discord если включено
  if (mcChatEnabled) {
    let chatMessage = message.toString().replace(/\u00A7./g, "");
    const channel = discordBot.channels.cache.get(channelId);
    if (channel) {
      channel.send(`📢 **Minecraft Chat:** ${chatMessage}`);
    }
  }
});

// === Авто-выход при обнаружении постороннего игрока ===
const DISCORD_WEBHOOK_URL = web1;

async function sendDiscordMessage(content) {
  try {
    await axios.post(DISCORD_WEBHOOK_URL, { content });
  } catch (error) {
    console.error("❌ Ошибка отправки в Discord:", error);
  }
}

function isWhitelisted(playerName) {
  return whitelist.includes(playerName);
}

let autoLeave = false;
let hasSentHubMessage = false;
let lastDimension = null;
let isInHubOnce = false;
let lastHubEnterTime = null;

// Добавляем конфигурацию безопасных зон
const SAFE_ZONES = [
    { x: 0.5, y: 100, z: 0.5, radius: 20, name: "Hub" }, // Хаб
    { x: 100, y: 100, z: 100, radius: 30, name: "Зона 1" }, // Пример безопасной зоны 1
    { x: -100, y: 100, z: -100, radius: 25, name: "Зона 2" }, // Пример безопасной зоны 2
];

// Добавляем массив для временных зон
let TEMP_SAFE_ZONES = [];

// Функция для добавления временной безопасной зоны
function addTempSafeZone(x, y, z, radius, name) {
    TEMP_SAFE_ZONES.push({ x: Number(x), y: Number(y), z: Number(z), radius: Number(radius), name });
    return `Временная зона "${name}" добавлена (x: ${x}, y: ${y}, z: ${z}, радиус: ${radius})`;
}

// Функция для удаления временной зоны по имени
function removeTempSafeZone(name) {
    const index = TEMP_SAFE_ZONES.findIndex(zone => zone.name === name);
    if (index !== -1) {
        TEMP_SAFE_ZONES.splice(index, 1);
        return `Временная зона "${name}" удалена`;
    }
    return `Временная зона "${name}" не найдена`;
}

// Обновляем функцию isInSafeZone с учетом временных зон
function isInSafeZone() {
    try {
        if (!bot.entity || !bot.entity.position) return false;
        
        // Проверяем постоянные зоны
        const inPermZone = SAFE_ZONES.some(zone => {
            try {
                const distance = bot.entity.position.distanceTo({ x: zone.x, y: zone.y, z: zone.z });
                return distance < zone.radius;
            } catch (error) {
                console.error("Ошибка при проверке дистанции до зоны:", error);
                return false;
            }
        });

        // Проверяем временные зоны
        const inTempZone = TEMP_SAFE_ZONES.some(zone => {
            try {
                const distance = bot.entity.position.distanceTo({ x: zone.x, y: zone.y, z: zone.z });
                return distance < zone.radius;
            } catch (error) {
                console.error("Ошибка при проверке дистанции до временной зоны:", error);
                return false;
            }
        });

        return inPermZone || inTempZone;
    } catch (error) {
        console.error("Ошибка при проверке безопасной зоны:", error);
        return false;
    }
}

// Обновляем функцию getCurrentZoneName с учетом временных зон
function getCurrentZoneName() {
    try {
        if (!bot.entity || !bot.entity.position) return "Неизвестно";
        
        // Проверяем постоянные зоны
        for (const zone of SAFE_ZONES) {
            try {
                const distance = bot.entity.position.distanceTo({ x: zone.x, y: zone.y, z: zone.z });
                if (distance < zone.radius) {
                    return zone.name;
                }
            } catch (error) {
                console.error("Ошибка при проверке дистанции до зоны:", error);
                continue;
            }
        }

        // Проверяем временные зоны
        for (const zone of TEMP_SAFE_ZONES) {
            try {
                const distance = bot.entity.position.distanceTo({ x: zone.x, y: zone.y, z: zone.z });
                if (distance < zone.radius) {
                    return `${zone.name} (временная)`;
                }
            } catch (error) {
                console.error("Ошибка при проверке дистанции до временной зоны:", error);
                continue;
            }
        }

        return "Вне безопасной зоны";
    } catch (error) {
        console.error("Ошибка при определении текущей зоны:", error);
        return "Ошибка определения зоны";
    }
}

// Обновляем обработчик physicTick с проверками
bot.on("physicTick", async () => {
    try {
        if (!autoLeave) return; // Если autoLeave выключен, прекращаем выполнение
        
        if (!bot.entity || !bot.entity.position) {
            console.log("Позиция бота недоступна");
            return;
        }
        
        if (isInSafeZone()) {
            hasSentHubMessage = false;
            return;
        }
        
        const nearbyPlayers = Object.values(bot.players)
            .filter(player => {
                try {
                    return player && 
                           player.entity && 
                           player.entity.position && 
                           !player.entity._isVehicle && 
                           !isWhitelisted(player.username) && // Проверяем вайтлист сразу в фильтре
                           bot.entity.position.distanceTo(player.entity.position) < 200;
                } catch (error) {
                    console.error('❌ Ошибка при проверке игрока:', error);
                    return false;
                }
            });
        
        if (nearbyPlayers.length > 0 && !hasSentHubMessage) {
            const playerNames = nearbyPlayers.map(p => p.username).join(', ');
            console.log(`⚠️ Опасность! Игрок(и) ${playerNames} рядом! Переходим в /hub!`);
            hasSentHubMessage = true;
            
            try {
                await sendDiscordMessage(
                    `⚠️ **Бот перешел в /hub!**\nИгрок(и) **${playerNames}** был(и) рядом.\nЛокация: ${getCurrentZoneName()}`
                );
                
                bot.chat("/hub");
            } catch (error) {
                console.error("Ошибка при отправке сообщения:", error);
            }
            
            setTimeout(() => {
                hasSentHubMessage = false;
            }, 5000);
        }
    } catch (error) {
        console.error('❌ Ошибка в обработчике physicTick:', error);
    }
});

// Обновляем обработчик move с проверками
bot.on('move', () => {
    try {
        if (!bot.entity || !bot.entity.position) return;
        // Убираем автоматическое включение autoLeave
    } catch (error) {
        console.error("Ошибка в обработчике move:", error);
    }
});

// === Обработка капчи ===
let captchaCount = 0;
const MAX_CAPTCHAS = 4;
let captchaFiles = []; // Массив для хранения путей к файлам капч

const captcha = new FlayerCaptcha(bot);

// Обработчик обнаружения капчи
captcha.on("detect", () => {
    console.log("🔍 Обнаружена капча!");
});

// Обработчик начала решения капчи
captcha.on("start", () => {
    console.log("🎯 Начато решение капчи...");
});

// Функция для проверки и создания директории
async function ensureDirectoryExists(dirPath) {
    try {
        await fs.promises.access(dirPath);
    } catch {
        await fs.promises.mkdir(dirPath, { recursive: true });
    }
}

// Функция для проверки существования файла
async function fileExists(filePath) {
    try {
        await fs.promises.access(filePath);
        return true;
    } catch {
        return false;
    }
}

// Функция для отправки всех капч в Discord
async function sendCaptchasToDiscord(files) {
    try {
        const channel = discordBot.channels.cache.get(channelId);
        if (!channel) {
            console.error("❌ Канал Discord не найден!");
            return;
        }

        // Проверяем существование всех файлов перед отправкой
        const existingFiles = [];
        for (const file of files) {
            if (await fileExists(file)) {
                existingFiles.push(file);
            } else {
                console.error(`❌ Файл не найден: ${file}`);
            }
        }

        if (existingFiles.length === MAX_CAPTCHAS) {
            console.log("📤 Отправка всех 4 капч в Discord...");
            await channel.send({
                content: "📸 Набор из 4 капч:",
                files: existingFiles
            });
            console.log("✅ Все капчи успешно отправлены!");
            return true;
        } else {
            console.error(`❌ Найдено только ${existingFiles.length} из ${MAX_CAPTCHAS} файлов капч`);
            return false;
        }
    } catch (error) {
        console.error("❌ Ошибка при отправке капч в Discord:", error);
        await sendDiscordMessage("❌ Ошибка при отправке капч: " + error.message);
        return false;
    }
}

// Обновляем обработчик успешного решения капчи
captcha.on("success", async (image) => {
    if (!captchaEnabled) {
        console.log("ℹ️ Обработка капчи отключена");
        return;
    }

    try {
        // Создаем директорию для капч если её нет
        const captchaDir = path.join(__dirname, 'captchas');
        await ensureDirectoryExists(captchaDir);

        // Увеличиваем счетчик и определяем имя файла
        captchaCount++;
        const currentFileName = path.join(captchaDir, `captcha_${captchaCount}.png`);

        // Сохраняем капчу
        console.log(`📸 Сохранение капчи ${captchaCount}/4 в файл captcha_${captchaCount}.png...`);
        await image.toFile(currentFileName);
        
        // Проверяем, что файл действительно создан
        if (await fileExists(currentFileName)) {
            console.log(`✅ Капча ${captchaCount}/4 успешно сохранена`);
            captchaFiles.push(currentFileName);
        } else {
            console.error(`❌ Ошибка: Файл ${currentFileName} не был создан`);
            return;
        }

        // Если собрали все 4 капчи
        if (captchaCount === MAX_CAPTCHAS) {
            console.log(`📁 Собрано капч: ${captchaFiles.length}/${MAX_CAPTCHAS}`);
            
            // Пытаемся отправить капчи
            const sent = await sendCaptchasToDiscord([...captchaFiles]);
            
            if (sent) {
                // Сбрасываем счетчики только если отправка успешна
                captchaCount = 0;
                captchaFiles = [];
                console.log("🔄 Готовы к сбору нового набора капч");
            } else {
                console.log("⚠️ Отправка не удалась, сохраняем капчи для следующей попытки");
            }
        }

    } catch (error) {
        console.error("❌ Ошибка при сохранении капчи:", error);
        await sendDiscordMessage("❌ Ошибка при сохранении капчи: " + error.message);
    }
});

// Обработчик ошибки капчи
captcha.on("error", async (error) => {
    console.error("❌ Ошибка при обработке капчи:", error);
    await sendDiscordMessage("❌ Ошибка при обработке капчи: " + error.message);
});

// === Карта координат слотов инвентаря (для скриншота) ===
const slotPositions = {
  armor: [
    [8, 8],
    [8, 26],
    [8, 44],
    [8, 62],
  ], // Броня (шлем -> ботинки)
  offhand: [[152, 62]], // Левая рука
  main: [...Array(27).keys()].map((i) => [
    8 + (i % 9) * 18,
    84 + Math.floor(i / 9) * 18,
  ]), // Основной инвентарь (9х3)
  hotbar: [...Array(9).keys()].map((i) => [8 + i * 18, 142]), // Быстрая панель (слоты 36-44!)
};

console.warn = () => {}; // Отключаем предупреждения

// === Функция дропа предмета из указанного слота ===
function dropItem(slot) {
  const item = bot.inventory.slots[slot];
  if (!item) {
    console.log(`❌ Слот ${slot} пуст.`);
    return;
  }
  bot.tossStack(item, (err) => {
    if (err) {
      console.log(`❌ Ошибка при выбрасывании предмета из слота ${slot}:`, err);
    } else {
      console.log(`✅ Выброшен предмет: ${item.name} (слот ${slot})`);
    }
  });
}

// Добавляем команду drop через консоль и Discord
rl.on("line", (input) => {
  const args = input.split(" ");
  const command = args[0];
  if (command === "drop" && args[1]) {
    const slot = parseInt(args[1]);
    if (!isNaN(slot)) {
      dropItem(slot);
    } else {
      console.log("❌ Укажите корректный номер слота.");
    }
  }
});

discordBot.on("messageCreate", (message) => {
  if (message.author.bot) return;
  const args = message.content.trim().split(/\s+/);
  const command = args[0].toLowerCase();
  if (command === "!drop" && args[1]) {
    const slot = parseInt(args[1]);
    if (!isNaN(slot)) {
      dropItem(slot);
      message.reply(`✅ Выброшен предмет из слота ${slot}`);
    } else {
      message.reply("❌ Укажите корректный номер слота.");
    }
  }
});

// === Функция создания скриншота инвентаря и отправки его в Discord ===
async function saveInventorySnapshot() {
  const inventory = bot.inventory.slots;
  const canvas = createCanvas(176, 166); // Размер GUI инвентаря
  const ctx = canvas.getContext("2d");
  console.log("📦 Создаём снимок инвентаря...");

  // Загрузка фонового изображения
  try {
    const background = await loadImage(
      path.join(__dirname, "inventory_background.png"),
    );
    ctx.drawImage(background, 0, 0);
  } catch (err) {
    console.warn("⚠️ Фон инвентаря не найден. Используется пустой фон.");
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }

  // Папки с иконками
  const iconFolders = ['icons', 'icons2', 'icons3', 'icons4', 'icons5'];

  // Отрисовка предметов
  for (let slot = 0; slot < inventory.length; slot++) {
    const item = inventory[slot];
    if (!item) continue;
    let position;
    if (slot >= 5 && slot <= 8) position = slotPositions.armor[slot - 5];
    else if (slot === 45) position = slotPositions.offhand[0];
    else if (slot >= 9 && slot <= 35) position = slotPositions.main[slot - 9];
    else if (slot >= 36 && slot <= 44)
      position = slotPositions.hotbar[slot - 36];
    else continue;

    // Ищем иконку в каждой папке
    let iconFound = false;
    for (const folder of iconFolders) {
      const iconPath = path.join(__dirname, folder, `${item.name}.png`);
      if (fs.existsSync(iconPath)) {
        try {
          const img = await loadImage(iconPath);
          ctx.drawImage(img, position[0], position[1], 16, 16);
          if (item.count > 1) {
            ctx.font = "12px Arial";
            ctx.fillStyle = "white";
            ctx.textAlign = "right";
            ctx.fillText(item.count, position[0] + 16, position[1] + 16);
          }
          iconFound = true;
          break;
        } catch (err) {
          continue;
        }
      }
    }
    
    if (!iconFound) {
      console.warn(`⚠️ Иконка для ${item.name} не найдена ни в одной папке.`);
    }
  }

  // Сохранение изображения
  const filePath = path.join(__dirname, "inventory.png");
  const buffer = canvas.toBuffer("image/png");
  fs.writeFileSync(filePath, buffer);
  console.log("📸 Снимок инвентаря сохранен как inventory.png");

  // Отправка скриншота в Discord
  await sendInventoryScreenshotToDiscord(filePath);
}

// Функция отправки скриншота в Discord через Discord-бота
async function sendInventoryScreenshotToDiscord(filePath) {
  try {
    const channel = discordBot.channels.cache.get(channelId);
    if (!channel) {
      console.error("Канал Discord не найден!");
      return;
    }
    await channel.send({ files: [filePath] });
    console.log("Скриншот инвентаря отправлен в Discord!");
  } catch (error) {
    console.error("Ошибка отправки скриншота в Discord:", error);
  }
}

// Вход в Discord
discordBot.login(token);

let messageLoops = {}; // Объект для хранения активных циклов сообщений

// Функция для запуска цикла сообщений с разными интервалами
function startMessageLoops() {
  messages.forEach((msgObj, index) => {
    const loopId = `loop_${index}`;
    if (!messageLoops[loopId]) {
      messageLoops[loopId] = setInterval(() => {
        bot.chat(msgObj.message);
      }, msgObj.interval);
    }
  });
}

// Функция для остановки всех циклов
function stopAllMessageLoops() {
  Object.keys(messageLoops).forEach((loopId) => {
    clearInterval(messageLoops[loopId]);
    delete messageLoops[loopId];
    console.log(`Цикл "${loopId}" остановлен.`);
  });
}

// Запуск циклов сообщений при старте бота
startMessageLoops(); // Автоматически запускаем циклы при старте бота

// Функция для переподключения бота
async function reconnectBot() {
    if (!autoReconnectEnabled) return;
    console.log('Попытка переподключения...');
    
    try {
        // Создаём нового бота с теми же параметрами
        const newBot = mineflayer.createBot({
            username: mcUsername,
            password: mcPassword,
            host: mcServerHost,
            port: mcServerPort,
            version: "1.16.5",
            agent: new ProxyAgent({
                protocol: "socks5:",
                host: proxyHost,
                port: proxyPort,
                username: proxyUsername,
                password: proxyPassword,
            }),
            connect: (client) => {
                socks.createConnection(
                    {
                        proxy: {
                            host: proxyHost,
                            port: proxyPort,
                            type: 5,
                            userId: proxyUsername,
                            password: proxyPassword,
                        },
                        command: "connect",
                        destination: {
                            host: mcServerHost,
                            port: mcServerPort,
                        },
                    },
                    (err, info) => {
                        if (err) {
                            console.log(err);
                            return;
                        }
                        client.setSocket(info.socket);
                        client.emit("connect");
                    },
                );
            }
        });

        // Заменяем старого бота новым
        bot = newBot;
        
        // Переустанавливаем все обработчики событий
        bot.loadPlugin(safeAutoClicker.inject);
        
        // Восстанавливаем все обработчики событий
        setupBotHandlers(bot);
        
        bot.once("spawn", () => {
            console.log("Бот успешно переподключен");
            sendDiscordMessage("✅ Бот успешно переподключен к серверу!");
            
            // Восстанавливаем предыдущие состояния
            if (isSneaking) bot.setControlState("sneak", true);
            if (autoclickerActive) bot.autoclicker.start();
            
            // Проверяем местоположение бота и устанавливаем autoLeave
            setTimeout(() => {
                if (!isInSafeZone()) {
                    autoLeave = true;
                } else {
                    autoLeave = false;
                }
            }, 2000); // Даем боту время заспавниться и получить координаты
        });
        
    } catch (error) {
        console.error('Ошибка при переподключении:', error);
        await sendDiscordMessage("❌ Ошибка при попытке переподключения бота!");
        
        // Пробуем переподключиться снова через 30 секунд
        setTimeout(reconnectBot, 30000);
    }
}

// === Функция для установки всех обработчиков событий бота ===
function setupBotHandlers(bot) {
  // Добавляем обработчик ошибок для всех событий
  bot.on('error', (error) => {
    console.error('❌ Ошибка бота:', error);
    sendDiscordMessage(`❌ Произошла ошибка бота: ${error.message}`);
  });

  // Обработчик отключения
  bot.on('end', () => {
    console.log('Бот отключен от сервера');
    sendDiscordMessage("⚠️ Бот отключен от сервера");
    
    if (autoReconnectEnabled) {
      console.log('Попытка переподключения через 5 секунд...');
      setTimeout(reconnectBot, 5000);
    }
  });

  // Безопасная инициализация обработки сущностей
  bot.on('spawn', () => {
    try {
      // Инициализируем entities если оно не существует
      if (!bot.entities) {
        bot.entities = {};
      }

      // Добавляем безопасный метод обновления
      if (!bot.entities.update) {
        bot.entities.update = function(packet) {
          try {
            if (!packet || packet.entityId === undefined) return;
            
            // Создаем сущность если её нет
            if (!this[packet.entityId]) {
              this[packet.entityId] = {
                id: packet.entityId,
                position: { x: 0, y: 0, z: 0 },
                passengers: []
              };
            }

            // Безопасное обновление свойств
            const entity = this[packet.entityId];
            if (!entity.passengers) entity.passengers = [];
            if (!entity.position) entity.position = { x: 0, y: 0, z: 0 };

          } catch (error) {
            console.error('❌ Ошибка при обработке сущности:', error);
          }
        };
      }
    } catch (error) {
      console.error('❌ Ошибка при инициализации обработки сущностей:', error);
    }
  });

  // Остальные обработчики...
  bot.on('move', () => {
    try {
      if (!bot.entity || !bot.entity.position) return;
      
      if (!isInSafeZone() && !autoLeave) {
        autoLeave = true;
      }
    } catch (error) {
      console.error("Ошибка в обработчике move:", error);
    }
  });

  // Обработчик респавна
  bot.on("respawn", async () => {
    try {
      // Сохраняем состояние автокликера, автоеды и автолива
      const wasAutoclickerActive = autoclickerActive;
      const wasAutoEatActive = autoEat;
      const wasAutoLeaveActive = autoLeave; // Сохраняем состояние autoLeave

      // Отключаем автокликер и автоеду
      if (autoclickerActive) {
        bot.autoclicker.stop();
        autoclickerActive = false;
      }

      if (autoEat) {
        autoEat = false;
      }

      // Ждем 1 секунду перед повторным включением
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Включаем функции снова только если они были активны
      if (wasAutoclickerActive) {
        bot.autoclicker.start();
        autoclickerActive = true;
      }

      if (wasAutoEatActive) {
        autoEat = true;
      }
      
      // Восстанавливаем состояние autoLeave
      autoLeave = wasAutoLeaveActive;
      
      // Обработка приседания при респавне
      toggleSneak();
      setTimeout(() => {
        toggleSneak();
      }, 1500);

      // Проверка состояния autoLeave после респавна
      if (!isInSafeZone()) {
        autoLeave = true;
      }
    } catch (error) {
      console.error("Ошибка в обработчике respawn:", error);
    }
  });

  // Обработчик здоровья для автоеды
  bot.on("health", async () => {
    try {
      if (bot.food < 20 && autoEat && !isEating) {
        await tryEat();
      }
    } catch (error) {
      console.error("Ошибка в обработчике health:", error);
    }
  });

  // Обработчик сообщений в чат
  bot.on("message", (message) => {
    try {
      if (showChat) console.log(`[CHAT] ${message.toAnsi()}`);
      
      if (mcChatEnabled) {
        let chatMessage = message.toString().replace(/\u00A7./g, "");
        const channel = discordBot.channels.cache.get(channelId);
        if (channel) {
          channel.send(`📢 **Minecraft Chat:** ${chatMessage}`);
        }
      }
    } catch (error) {
      console.error("Ошибка в обработчике message:", error);
    }
  });
}

// Устанавливаем обработчики для начального бота
setupBotHandlers(bot);

// Отключаем предупреждения о устаревших модулях
process.emitWarning = function() {};

// Обновляем функцию cleanExit
async function cleanExit() {
    try {
        console.log("🔄 Отключаю все активные процессы...");
        
        // Останавливаем все циклы сообщений
        stopAllMessageLoops();
        
        // Останавливаем автокликер если активен
        if (autoclickerActive) {
            bot.autoclicker.stop();
        }
        
        // Отключаем автопереподключение
        autoReconnectEnabled = false;
        
        // Отправляем последнее сообщение в Discord
        await sendDiscordMessage("🚪 Бот завершает работу...");
        
        try {
            // Корректно отключаем бота Minecraft
            await bot.end();
            
            // Корректно отключаем Discord бота
            await discordBot.destroy();
            
            console.log("✅ Все процессы успешно завершены");
        } catch (err) {
            // Игнорируем ошибки при отключении
        }
        
        // Используем process.exit с небольшой задержкой
        setTimeout(() => {
            process.exit(0);
        }, 1000);
    } catch (error) {
        process.exit(1);
    }
}

// Добавляем патч для безопасной работы с сущностями
const safeEntityHandler = {
    get: function(target, prop) {
        try {
            if (prop === 'passengers' && !target[prop]) {
                target[prop] = [];
            }
            return target[prop];
        } catch (error) {
            console.error('❌ Ошибка при доступе к свойству сущности:', error);
            return prop === 'passengers' ? [] : undefined;
        }
    },
    set: function(target, prop, value) {
        try {
            target[prop] = value;
            return true;
        } catch (error) {
            console.error('❌ Ошибка при установке свойства сущности:', error);
            return false;
        }
    }
};

// Применяем прокси к сущностям бота
bot.on('entitySpawn', (entity) => {
    try {
        if (!entity) return;
        
        // Оборачиваем сущность в прокси для безопасного доступа к свойствам
        bot.entities[entity.id] = new Proxy(entity, safeEntityHandler);
        
        if (entity.type === 'vehicle') {
            console.log(`🚗 Обнаружено транспортное средство: ${entity.name || 'Неизвестно'}`);
        }
    } catch (error) {
        console.error('❌ Ошибка при инициализации сущности:', error);
    }
});

// Добавляем функцию для сохранения состояния капчи в конфиг
async function saveCaptchaState() {
    try {
        const configPath = './config_rak6.json';
        const config = require(configPath);
        config.captchaEnabled = captchaEnabled;
        await fs.promises.writeFile(configPath, JSON.stringify(config, null, 2));
        console.log(`✅ Состояние капчи сохранено: ${captchaEnabled ? "включено" : "выключено"}`);
    } catch (error) {
        console.error("❌ Ошибка при сохранении состояния капчи:", error);
    }
}

// Добавляем функцию для переключения состояния капчи
async function toggleCaptcha() {
    captchaEnabled = !captchaEnabled;
    await saveCaptchaState();
    const status = captchaEnabled ? "включена" : "выключена";
    console.log(`🔄 Обработка капчи ${status}`);
    return status;
}


